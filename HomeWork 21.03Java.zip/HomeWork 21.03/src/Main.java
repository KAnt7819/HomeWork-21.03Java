public class Main {
    // Напишите метод, который принимает три строки и строку-разделитель.
    // Метод возвращает единую строку, состоящую из исходных строк, разделённых строкой-разделителем. Например,
    // на входе "один", "два", "три", "|". На выходе: "один|два|три"
    //2 Напишите метод, который выводит в консоль первый символ переданной в него строки.
    public static void main(String[] args) {
        String s = concat("perwaja stroka", "vtoraja stroka", "tretja stroka", "|");
        System.out.println(s);
        String a = "Towner have a dog";
        conclusion(a);
    }

    private static String concat(String s1, String s2, String s3, String delimiter) {
        return s1 + delimiter + s2 + delimiter + s3;
    }

    private static void conclusion(String a) {
        System.out.println(a.charAt(0));
    }

}